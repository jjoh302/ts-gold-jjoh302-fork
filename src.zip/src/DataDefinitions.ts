export enum FieldName {
    STORE = 'Store ID',
    CATEGORY = 'Category',
    GROUP = 'Group',
    DIVISION = 'Division',
    DISTRICT = 'District',
    UPC = 'Internet Item Description'
}
export enum FieldLabel {
    STORE = 'STORES',
    CATEGORY = 'CATEGORIES',
    GROUP = 'GROUPS',
    DIVISION = 'DIVISIONS',
    DISTRICT = 'DISTRICTS',
    UPC = 'UPC'
}
export const BaseFields: string[] = [
    'Size',
    'Pack Size',
    'Manufacture Type Code',
    'Sales',
    'Sales PY',
    'Units'
]
